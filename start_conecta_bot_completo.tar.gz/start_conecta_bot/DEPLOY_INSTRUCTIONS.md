# 🚀 Instruções de Deploy - Bot START Conecta

## Passo 1: Criar Repositório no GitHub

1. **Acesse**: https://github.com/new
2. **Nome do repositório**: `start-conecta-bot`
3. **Descrição**: `Bot de atendimento automatizado START Conecta - WhatsApp Z-API`
4. **Visibilidade**: Público ✅
5. **Inicializar com README**: ❌ (não marcar)
6. **Clique em**: "Create repository"

## Passo 2: Upload dos Arquivos

Após criar o repositório, você verá uma página com instruções. Siga estas etapas:

### Opção A: Upload via Interface Web
1. Clique em "uploading an existing file"
2. Arraste todos os arquivos do projeto:
   - `app.py`
   - `bot_logic.py`
   - `z_api_client.py`
   - `requirements.txt`
   - `README.md`
   - `.gitignore`
3. Adicione uma mensagem de commit: "Initial commit - Bot START Conecta"
4. Clique em "Commit new files"

### Opção B: Via Git (se tiver Git instalado)
```bash
git remote add origin https://github.com/SEU_USUARIO/start-conecta-bot.git
git branch -M main
git push -u origin main
```

## Passo 3: Deploy no Render

1. **Acesse**: https://dashboard.render.com/
2. **Faça login** ou crie uma conta
3. **Clique em**: "New +" → "Web Service"
4. **Conecte ao GitHub**: Autorize o Render a acessar seus repositórios
5. **Selecione**: o repositório `start-conecta-bot`
6. **Configure**:
   - **Name**: `start-conecta-bot`
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python app.py`
   - **Plan**: Free (para testes)

## Passo 4: Configurar Variáveis de Ambiente

No painel do Render, vá em "Environment" e adicione:

```
ZAPI_INSTANCE_ID = seu_instance_id_aqui
ZAPI_TOKEN = seu_token_aqui
```

**⚠️ IMPORTANTE**: Substitua pelos valores reais do seu Z-API!

## Passo 5: Fazer Deploy

1. **Clique em**: "Create Web Service"
2. **Aguarde**: O deploy será feito automaticamente (5-10 minutos)
3. **URL do bot**: Será algo como `https://start-conecta-bot-xxxx.onrender.com`

## Passo 6: Configurar Webhook no Z-API

1. **Acesse**: https://app.z-api.io/app
2. **Vá em**: Configurações → Webhooks
3. **URL do Webhook**: `https://SEU_APP.onrender.com/webhook`
4. **Eventos**: Marque "Mensagem Recebida"
5. **Salve** as configurações

## Passo 7: Testar o Bot

1. **Envie uma mensagem** para o número do WhatsApp conectado ao Z-API
2. **O bot deve responder** com a mensagem de boas-vindas
3. **Teste as opções** do menu principal

## 🔧 Solução de Problemas

### Bot não responde:
- Verifique se o webhook está configurado corretamente
- Confirme se as variáveis de ambiente estão corretas
- Verifique os logs no Render

### Erro de deploy:
- Verifique se todos os arquivos foram enviados
- Confirme se o `requirements.txt` está correto
- Verifique os logs de build no Render

### Webhook não funciona:
- Teste a URL do webhook no navegador (deve retornar status do bot)
- Verifique se a URL está correta no Z-API
- Confirme se o serviço está rodando no Render

## 📞 URLs Importantes

- **Render Dashboard**: https://dashboard.render.com/
- **Z-API Dashboard**: https://app.z-api.io/app
- **GitHub**: https://github.com/
- **Documentação Z-API**: https://developer.z-api.io/

## 🎯 Próximos Passos

Após o deploy bem-sucedido:

1. **Teste todas as funcionalidades** do bot
2. **Monitore os logs** para identificar possíveis melhorias
3. **Customize as mensagens** conforme necessário
4. **Configure alertas** no Render para monitoramento

---

**✅ Pronto!** Seu bot START Conecta estará funcionando e pronto para atender clientes via WhatsApp!

