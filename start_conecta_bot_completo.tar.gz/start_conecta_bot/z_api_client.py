import requests
import json

class ZAPIClient:
    def __init__(self, instance_id, token):
        self.instance_id = instance_id
        self.token = token
        self.base_url = f"https://api.z-api.io/instances/{instance_id}/token/{token}"
    
    def send_text_message(self, phone, message):
        """Envia uma mensagem de texto para um número de telefone"""
        url = f"{self.base_url}/send-text"
        
        payload = {
            "phone": phone,
            "message": message
        }
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, headers=headers, data=json.dumps(payload))
            return response.json()
        except Exception as e:
            print(f"Erro ao enviar mensagem: {e}")
            return None
    
    def send_button_message(self, phone, message, buttons):
        """Envia uma mensagem com botões"""
        url = f"{self.base_url}/send-button-list"
        
        payload = {
            "phone": phone,
            "message": message,
            "buttonList": {
                "buttons": buttons
            }
        }
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, headers=headers, data=json.dumps(payload))
            return response.json()
        except Exception as e:
            print(f"Erro ao enviar mensagem com botões: {e}")
            return None
    
    def send_option_list(self, phone, message, title, options):
        """Envia uma mensagem com lista de opções"""
        url = f"{self.base_url}/send-option-list"
        
        payload = {
            "phone": phone,
            "message": message,
            "optionList": {
                "title": title,
                "options": options
            }
        }
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, headers=headers, data=json.dumps(payload))
            return response.json()
        except Exception as e:
            print(f"Erro ao enviar lista de opções: {e}")
            return None

