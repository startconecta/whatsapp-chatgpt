# 🔗 Configuração do Webhook Z-API

## Pré-requisitos

Antes de configurar o webhook, certifique-se de que:

✅ O bot está deployado no Render  
✅ A URL do Render está funcionando (ex: `https://start-conecta-bot-xxxx.onrender.com`)  
✅ Você tem acesso ao painel do Z-API  
✅ Sua instância do Z-API está ativa  

## Passo 1: Acessar o Painel Z-API

1. **Acesse**: https://app.z-api.io/app
2. **Faça login** com suas credenciais
3. **Selecione** sua instância do WhatsApp

## Passo 2: Localizar as Configurações de Webhook

1. No painel principal, procure por:
   - **"Webhooks"** ou
   - **"Configurações"** → **"Webhooks"** ou
   - **"Settings"** → **"Webhooks"**

## Passo 3: Configurar o Webhook de Mensagens

### URL do Webhook
```
https://SEU_APP_RENDER.onrender.com/webhook
```

**⚠️ Substitua `SEU_APP_RENDER` pelo nome real do seu app no Render!**

### Eventos para Ativar
Marque as seguintes opções:

✅ **Message Received** (Mensagem Recebida)  
✅ **Text Message** (Mensagem de Texto)  
❌ Status de Entrega (opcional)  
❌ Status de Leitura (opcional)  

### Método HTTP
- **Método**: `POST`
- **Content-Type**: `application/json`

## Passo 4: Testar a Configuração

### Teste 1: Verificar URL
1. Abra a URL do webhook no navegador
2. Deve retornar: `{"status": "Bot START Conecta está funcionando!", "version": "1.0"}`

### Teste 2: Enviar Mensagem de Teste
1. Envie qualquer mensagem para o número do WhatsApp
2. O bot deve responder com a mensagem de boas-vindas

## Passo 5: Verificar Logs (Opcional)

### No Render:
1. Acesse o dashboard do Render
2. Vá em seu serviço
3. Clique em "Logs"
4. Verifique se aparecem mensagens como: `Webhook recebido: {...}`

### No Z-API:
1. Verifique se há logs de webhook enviados
2. Confirme se o status é 200 (sucesso)

## 🔧 Solução de Problemas

### Webhook não está sendo chamado:
- ✅ Verifique se a URL está correta
- ✅ Confirme se o serviço está rodando no Render
- ✅ Teste a URL manualmente no navegador

### Bot não responde:
- ✅ Verifique os logs no Render
- ✅ Confirme se as variáveis de ambiente estão configuradas
- ✅ Teste o endpoint `/test` do bot

### Erro 500 no webhook:
- ✅ Verifique se `ZAPI_INSTANCE_ID` e `ZAPI_TOKEN` estão corretos
- ✅ Confirme se o formato da mensagem está correto
- ✅ Verifique os logs de erro no Render

## 📋 Exemplo de Configuração Completa

```json
{
  "webhook_url": "https://start-conecta-bot-xxxx.onrender.com/webhook",
  "events": [
    "message-received"
  ],
  "method": "POST",
  "headers": {
    "Content-Type": "application/json"
  }
}
```

## 🎯 Próximos Passos

Após configurar o webhook:

1. **Teste todas as opções** do menu do bot
2. **Verifique se as respostas** estão corretas
3. **Monitore os logs** para identificar problemas
4. **Ajuste as mensagens** conforme necessário

---

**✅ Webhook configurado com sucesso!** Seu bot agora está pronto para atender clientes automaticamente via WhatsApp.

