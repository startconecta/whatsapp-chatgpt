# Bot START Conecta - Integração Z-API + Render

Este é um bot de atendimento automatizado para WhatsApp usando Z-API e hospedado no Render.

## Funcionalidades

O bot implementa um fluxo completo de atendimento com as seguintes opções:

1. **Segunda via de boleto** - Solicita CPF/CNPJ e gera segunda via
2. **Suporte Técnico** - Diagnóstico de problemas de internet
3. **Contratar internet** - Verificação de cobertura e contratação
4. **Consultar cobertura** - Verificação de disponibilidade por CEP
5. **Cancelamento ou troca de plano** - Solicitações de alteração
6. **Falar com atendente humano** - Transferência para atendimento

## Configuração

### Variáveis de Ambiente

Configure as seguintes variáveis no Render:

- `ZAPI_INSTANCE_ID`: ID da sua instância no Z-API
- `ZAPI_TOKEN`: Token de acesso do Z-API
- `PORT`: Porta da aplicação (configurada automaticamente pelo Render)

### Deploy no Render

1. Faça fork deste repositório
2. Conecte sua conta do Render ao GitHub
3. Crie um novo Web Service no Render
4. Conecte ao repositório
5. Configure as variáveis de ambiente
6. Faça o deploy

### Configuração do Webhook no Z-API

Após o deploy, configure o webhook no Z-API:

1. Acesse o painel do Z-API
2. Vá em Configurações > Webhooks
3. Configure a URL: `https://seu-app.onrender.com/webhook`
4. Ative o webhook para mensagens recebidas

## Estrutura do Projeto

- `app.py` - Aplicação Flask principal
- `bot_logic.py` - Lógica do fluxo de atendimento
- `z_api_client.py` - Cliente para comunicação com Z-API
- `requirements.txt` - Dependências Python

## Testando Localmente

```bash
pip install -r requirements.txt
export ZAPI_INSTANCE_ID=your_instance_id
export ZAPI_TOKEN=your_token
python app.py
```

## Endpoints

- `GET /` - Health check
- `POST /webhook` - Recebe mensagens do Z-API
- `POST /test` - Endpoint para testes locais

## Licença

MIT License

