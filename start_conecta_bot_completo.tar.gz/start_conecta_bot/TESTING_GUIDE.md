# 🧪 Guia de Testes - Bot START Conecta

## Visão Geral

Este guia fornece um roteiro completo para testar todas as funcionalidades do bot de atendimento automatizado da START Conecta. Os testes devem ser realizados após o deploy e configuração do webhook.

## Pré-requisitos para Testes

✅ Bot deployado no Render  
✅ Webhook configurado no Z-API  
✅ Instância do WhatsApp ativa  
✅ Número de teste disponível  

## 1. Teste de Conectividade

### 1.1 Teste de Health Check
**URL**: `https://seu-app.onrender.com/`  
**Resultado esperado**: `{"status": "Bot START Conecta está funcionando!", "version": "1.0"}`

### 1.2 Teste de Webhook
**URL**: `https://seu-app.onrender.com/webhook`  
**Método**: GET  
**Resultado esperado**: Erro 405 (Method Not Allowed) - isso é normal, pois o webhook só aceita POST

## 2. Testes do Fluxo Principal

### 2.1 Mensagem de Boas-vindas
**Ação**: Envie qualquer mensagem para iniciar conversa  
**Mensagem de teste**: "Oi"

**Resposta esperada**:
```
Olá! 🙋 Eu sou o Atendente Theo, assistente virtual da START Conecta! Estou aqui para te ajudar com informações, suporte, boletos e muito mais.

Escolha uma das opções abaixo:
1 - Segunda via de boleto
2 - Suporte Técnico
3 - Contratar internet
4 - Consultar cobertura
5 - Cancelamento ou troca de plano
6 - Falar com um atendente humano
```

## 3. Teste da Opção 1 - Segunda Via de Boleto

### 3.1 Seleção da Opção
**Mensagem**: "1"

**Resposta esperada**:
```
Digite o CPF ou CNPJ do titular da conta. Vou buscar sua segunda via no sistema.
```

### 3.2 CPF Válido
**Mensagem**: "12345678901"

**Resposta esperada**:
```
Documento 12345678901 localizado! Estou gerando sua segunda via de boleto. Em alguns instantes você receberá o link para download.
```

### 3.3 CPF Inválido
**Mensagem**: "123"

**Resposta esperada**:
```
CPF ou CNPJ inválido. Por favor, digite novamente apenas os números.
```

## 4. Teste da Opção 2 - Suporte Técnico

### 4.1 Seleção da Opção
**Mensagem**: "2"

**Resposta esperada**:
```
Qual é o seu problema?
a - Sem internet
b - Internet lenta
c - Modem desligado
d - Outro problema
```

### 4.2 Teste "Sem Internet" (Opção A)

#### 4.2.1 Seleção
**Mensagem**: "a"

**Resposta esperada**:
```
Está vendo alguma luz vermelha piscando no equipamento? (Sim / Não)
```

#### 4.2.2 Resposta "Sim"
**Mensagem**: "sim"

**Resposta esperada**:
```
Verifique se o conector óptico está bem encaixado e alinhado com o trilho do acoplador. Fez isso?
```

#### 4.2.3 Confirmação
**Mensagem**: "sim"

**Resposta esperada**:
```
Vou agendar uma visita técnica. Prefere atendimento:
1 - Manhã (8h-12h)
2 - Tarde (13h-17h)
```

#### 4.2.4 Escolha de Horário
**Mensagem**: "1"

**Resposta esperada**:
```
Visita técnica agendada para o período da manhã (8h-12h). Nossa equipe entrará em contato para confirmar o horário exato.
```

### 4.3 Teste "Internet Lenta" (Opção B)

#### 4.3.1 Seleção
**Mensagem**: "b"

**Resposta esperada**:
```
Em qual aplicativo você percebe lentidão?
```

#### 4.3.2 Aplicativo IPTV
**Mensagem**: "iptv"

**Resposta esperada**:
```
Aplicativos de IPTV não homologados pela Anatel podem travar ou parar de funcionar. Isso não é um problema da internet, e sim do aplicativo que é um serviço não autorizado.
```

#### 4.3.3 Outro Aplicativo
**Mensagem**: "youtube"

**Resposta esperada**:
```
Vamos fazer dois testes:

1. Velocidade: Acesse www.fast.com conectado na rede 5G e próximo ao roteador. Me diga o resultado.

2. Estabilidade: No YouTube, abra um vídeo em 4K com mais de 3 horas e pule para várias partes. Se carregar rápido, sua internet está boa.

Me informe os resultados dos testes.
```

## 5. Teste da Opção 3 - Contratar Internet

### 5.1 Seleção da Opção
**Mensagem**: "3"

**Resposta esperada**:
```
Me informe seu endereço completo ou CEP. Vou verificar se temos cobertura na sua região.
```

### 5.2 Informar Endereço
**Mensagem**: "Rua das Flores, 123, Centro, São Paulo - SP"

**Resposta esperada**:
```
Endereço registrado: Rua das Flores, 123, Centro, São Paulo - SP

✅ Temos cobertura! Nossos planos:

📶 100MB - R$ 79,90
📶 200MB - R$ 99,90
📶 500MB - R$ 149,90

Nossa equipe comercial entrará em contato em até 2 horas para finalizar sua contratação!
```

## 6. Teste da Opção 4 - Consultar Cobertura

### 6.1 Seleção da Opção
**Mensagem**: "4"

**Resposta esperada**:
```
Digite seu CEP ou endereço completo para verificar a disponibilidade dos nossos planos na sua região.
```

### 6.2 Informar CEP
**Mensagem**: "01234-567"

**Resposta esperada**:
```
Verificando cobertura para: 01234-567

✅ Temos cobertura na sua região! Nossos planos disponíveis:

📶 100MB - R$ 79,90
📶 200MB - R$ 99,90
📶 500MB - R$ 149,90

Deseja contratar algum plano?
```

## 7. Teste da Opção 5 - Cancelamento

### 7.1 Seleção da Opção
**Mensagem**: "5"

**Resposta esperada**:
```
Digite o CPF ou CNPJ do titular para continuar. Vou encaminhar sua solicitação para o setor responsável.
```

### 7.2 Informar CPF
**Mensagem**: "12345678901"

**Resposta esperada**:
```
Documento 12345678901 localizado! Sua solicitação foi encaminhada para o setor responsável. Nossa equipe entrará em contato em até 24 horas.
```

## 8. Teste da Opção 6 - Atendente Humano

### 8.1 Seleção da Opção
**Mensagem**: "6"

**Resposta esperada**:
```
Aguarde um momento. Vou te transferir para um de nossos atendentes. Nosso horário de atendimento é de segunda a sexta, das 8h às 18h.
```

## 9. Testes de Validação

### 9.1 Opção Inválida no Menu Principal
**Mensagem**: "9"

**Resposta esperada**:
```
Opção inválida. Por favor, escolha uma opção de 1 a 6.
```

### 9.2 Texto Não Reconhecido
**Mensagem**: "xyz123"

**Resposta esperada**: Mensagem de boas-vindas (reset do fluxo)

## 10. Testes de Performance

### 10.1 Múltiplas Mensagens Simultâneas
- Envie várias mensagens rapidamente
- Verifique se todas são processadas
- Confirme se o estado da conversa é mantido

### 10.2 Teste de Timeout
- Inicie uma conversa
- Aguarde 30 minutos sem enviar mensagens
- Envie uma nova mensagem
- Deve reiniciar o fluxo

## 11. Checklist de Validação Final

### Funcionalidades Básicas
- [ ] Bot responde à primeira mensagem
- [ ] Menu principal é exibido corretamente
- [ ] Todas as 6 opções funcionam
- [ ] Validações de entrada funcionam
- [ ] Estados de conversa são mantidos

### Fluxos Específicos
- [ ] Segunda via de boleto (CPF válido/inválido)
- [ ] Suporte técnico (todas as sub-opções)
- [ ] Contratação de internet
- [ ] Consulta de cobertura
- [ ] Cancelamento/troca de plano
- [ ] Transferência para atendente

### Aspectos Técnicos
- [ ] Webhook recebe mensagens corretamente
- [ ] Logs aparecem no Render
- [ ] Não há erros 500
- [ ] Respostas são enviadas rapidamente (< 5 segundos)

## 12. Relatório de Problemas

Se encontrar problemas durante os testes, documente:

1. **Mensagem enviada**
2. **Resposta recebida** (ou ausência de resposta)
3. **Resposta esperada**
4. **Logs do Render** (se disponível)
5. **Horário do teste**

## 13. Próximos Passos

Após completar todos os testes:

1. **Documente** quaisquer problemas encontrados
2. **Ajuste** as mensagens conforme necessário
3. **Monitore** o comportamento em produção
4. **Colete feedback** dos usuários reais
5. **Implemente melhorias** baseadas no uso

---

**✅ Testes concluídos!** Seu bot START Conecta está pronto para atendimento em produção.

