import re
from z_api_client import ZAPIClient

class BotLogic:
    def __init__(self, z_api_client):
        self.z_api = z_api_client
        # Armazena o estado da conversa para cada usuário
        self.user_states = {}
    
    def process_message(self, phone, message_text):
        """Processa a mensagem e determina a resposta apropriada"""
        message_text = message_text.strip().lower()
        
        # Obtém o estado atual do usuário
        current_state = self.user_states.get(phone, 'start')
        
        if current_state == 'start':
            self.send_welcome_message(phone)
            self.user_states[phone] = 'waiting_main_option'
        
        elif current_state == 'waiting_main_option':
            self.handle_main_menu(phone, message_text)
        
        elif current_state == 'waiting_cpf_boleto':
            self.handle_cpf_boleto(phone, message_text)
        
        elif current_state == 'waiting_support_option':
            self.handle_support_menu(phone, message_text)
        
        elif current_state == 'waiting_internet_problem':
            self.handle_internet_problem(phone, message_text)
        
        elif current_state == 'waiting_red_light_answer':
            self.handle_red_light_answer(phone, message_text)
        
        elif current_state == 'waiting_connector_check':
            self.handle_connector_check(phone, message_text)
        
        elif current_state == 'waiting_schedule_preference':
            self.handle_schedule_preference(phone, message_text)
        
        elif current_state == 'waiting_slow_app':
            self.handle_slow_app(phone, message_text)
        
        elif current_state == 'waiting_speed_test':
            self.handle_speed_test(phone, message_text)
        
        elif current_state == 'waiting_address_coverage':
            self.handle_address_coverage(phone, message_text)
        
        elif current_state == 'waiting_address_contract':
            self.handle_address_contract(phone, message_text)
        
        elif current_state == 'waiting_cpf_cancel':
            self.handle_cpf_cancel(phone, message_text)
    
    def send_welcome_message(self, phone):
        """Envia a mensagem de boas-vindas com o menu principal"""
        welcome_text = """Olá! 🙋 Eu sou o Atendente Theo, assistente virtual da START Conecta! Estou aqui para te ajudar com informações, suporte, boletos e muito mais.

Escolha uma das opções abaixo:
1 - Segunda via de boleto
2 - Suporte Técnico
3 - Contratar internet
4 - Consultar cobertura
5 - Cancelamento ou troca de plano
6 - Falar com um atendente humano"""
        
        self.z_api.send_text_message(phone, welcome_text)
    
    def handle_main_menu(self, phone, message_text):
        """Processa a escolha do menu principal"""
        if message_text in ['1', 'segunda via', 'boleto']:
            self.z_api.send_text_message(phone, "Digite o CPF ou CNPJ do titular da conta. Vou buscar sua segunda via no sistema.")
            self.user_states[phone] = 'waiting_cpf_boleto'
        
        elif message_text in ['2', 'suporte', 'suporte técnico', 'suporte tecnico']:
            support_text = """Qual é o seu problema?
a - Sem internet
b - Internet lenta
c - Modem desligado
d - Outro problema"""
            self.z_api.send_text_message(phone, support_text)
            self.user_states[phone] = 'waiting_support_option'
        
        elif message_text in ['3', 'contratar', 'contratar internet']:
            self.z_api.send_text_message(phone, "Me informe seu endereço completo ou CEP. Vou verificar se temos cobertura na sua região.")
            self.user_states[phone] = 'waiting_address_contract'
        
        elif message_text in ['4', 'cobertura', 'consultar cobertura']:
            self.z_api.send_text_message(phone, "Digite seu CEP ou endereço completo para verificar a disponibilidade dos nossos planos na sua região.")
            self.user_states[phone] = 'waiting_address_coverage'
        
        elif message_text in ['5', 'cancelamento', 'troca', 'cancelar', 'trocar plano']:
            self.z_api.send_text_message(phone, "Digite o CPF ou CNPJ do titular para continuar. Vou encaminhar sua solicitação para o setor responsável.")
            self.user_states[phone] = 'waiting_cpf_cancel'
        
        elif message_text in ['6', 'atendente', 'humano', 'pessoa']:
            self.z_api.send_text_message(phone, "Aguarde um momento. Vou te transferir para um de nossos atendentes. Nosso horário de atendimento é de segunda a sexta, das 8h às 18h.")
            self.user_states[phone] = 'start'  # Reset para permitir nova conversa
        
        else:
            self.z_api.send_text_message(phone, "Opção inválida. Por favor, escolha uma opção de 1 a 6.")
    
    def handle_cpf_boleto(self, phone, message_text):
        """Processa o CPF/CNPJ para segunda via de boleto"""
        # Validação básica de CPF/CNPJ
        cpf_cnpj = re.sub(r'[^0-9]', '', message_text)
        
        if len(cpf_cnpj) == 11 or len(cpf_cnpj) == 14:
            self.z_api.send_text_message(phone, f"Documento {cpf_cnpj} localizado! Estou gerando sua segunda via de boleto. Em alguns instantes você receberá o link para download.")
            self.user_states[phone] = 'start'  # Reset para permitir nova conversa
        else:
            self.z_api.send_text_message(phone, "CPF ou CNPJ inválido. Por favor, digite novamente apenas os números.")
    
    def handle_support_menu(self, phone, message_text):
        """Processa a escolha do menu de suporte"""
        if message_text in ['a', 'sem internet']:
            self.z_api.send_text_message(phone, "Está vendo alguma luz vermelha piscando no equipamento? (Sim / Não)")
            self.user_states[phone] = 'waiting_red_light_answer'
        
        elif message_text in ['b', 'internet lenta', 'lenta']:
            self.z_api.send_text_message(phone, "Em qual aplicativo você percebe lentidão?")
            self.user_states[phone] = 'waiting_slow_app'
        
        elif message_text in ['c', 'modem desligado', 'desligado']:
            self.z_api.send_text_message(phone, "Verifique se o cabo de energia está conectado corretamente na tomada e no equipamento. Após conectar, aguarde alguns minutos para o equipamento inicializar completamente.")
            self.user_states[phone] = 'start'  # Reset
        
        elif message_text in ['d', 'outro', 'outro problema']:
            self.z_api.send_text_message(phone, "Descreva seu problema detalhadamente. Nossa equipe técnica irá analisar e entrar em contato.")
            self.user_states[phone] = 'start'  # Reset
        
        else:
            self.z_api.send_text_message(phone, "Opção inválida. Por favor, escolha a, b, c ou d.")
    
    def handle_red_light_answer(self, phone, message_text):
        """Processa a resposta sobre luz vermelha"""
        if message_text in ['sim', 's', 'yes']:
            self.z_api.send_text_message(phone, "Verifique se o conector óptico está bem encaixado e alinhado com o trilho do acoplador. Fez isso?")
            self.user_states[phone] = 'waiting_connector_check'
        
        elif message_text in ['não', 'nao', 'n', 'no']:
            self.z_api.send_text_message(phone, "Desligue o equipamento da tomada, aguarde 1 minuto e ligue novamente. Depois, verifique a luz PON:\n\n🟢 Verde fixa: sinal normal\n🟡 Verde piscando: sinal instável\n\nSe continuar piscando, me informe.")
            self.user_states[phone] = 'start'  # Reset
        
        else:
            self.z_api.send_text_message(phone, "Por favor, responda com 'Sim' ou 'Não'.")
    
    def handle_connector_check(self, phone, message_text):
        """Processa a verificação do conector"""
        if message_text in ['sim', 's', 'yes', 'fiz']:
            self.z_api.send_text_message(phone, "Vou agendar uma visita técnica. Prefere atendimento:\n1 - Manhã (8h-12h)\n2 - Tarde (13h-17h)")
            self.user_states[phone] = 'waiting_schedule_preference'
        
        elif message_text in ['não', 'nao', 'n', 'no']:
            self.z_api.send_text_message(phone, "Por favor, verifique o conector óptico e me informe se a luz vermelha parou de piscar.")
        
        else:
            self.z_api.send_text_message(phone, "Por favor, responda com 'Sim' ou 'Não'.")
    
    def handle_schedule_preference(self, phone, message_text):
        """Processa a preferência de horário"""
        if message_text in ['1', 'manhã', 'manha']:
            self.z_api.send_text_message(phone, "Visita técnica agendada para o período da manhã (8h-12h). Nossa equipe entrará em contato para confirmar o horário exato.")
            self.user_states[phone] = 'start'  # Reset
        
        elif message_text in ['2', 'tarde']:
            self.z_api.send_text_message(phone, "Visita técnica agendada para o período da tarde (13h-17h). Nossa equipe entrará em contato para confirmar o horário exato.")
            self.user_states[phone] = 'start'  # Reset
        
        else:
            self.z_api.send_text_message(phone, "Por favor, escolha 1 para manhã ou 2 para tarde.")
    
    def handle_slow_app(self, phone, message_text):
        """Processa o aplicativo com lentidão"""
        if 'iptv' in message_text.lower():
            self.z_api.send_text_message(phone, "Aplicativos de IPTV não homologados pela Anatel podem travar ou parar de funcionar. Isso não é um problema da internet, e sim do aplicativo que é um serviço não autorizado.")
            self.user_states[phone] = 'start'  # Reset
        
        else:
            speed_test_text = """Vamos fazer dois testes:

1. Velocidade: Acesse www.fast.com conectado na rede 5G e próximo ao roteador. Me diga o resultado.

2. Estabilidade: No YouTube, abra um vídeo em 4K com mais de 3 horas e pule para várias partes. Se carregar rápido, sua internet está boa.

Me informe os resultados dos testes."""
            
            self.z_api.send_text_message(phone, speed_test_text)
            self.user_states[phone] = 'waiting_speed_test'
    
    def handle_speed_test(self, phone, message_text):
        """Processa os resultados dos testes de velocidade"""
        self.z_api.send_text_message(phone, "Obrigado pelos resultados. Se mesmo assim estiver com problemas, vou agendar uma visita técnica. Prefere atendimento:\n1 - Manhã (8h-12h)\n2 - Tarde (13h-17h)")
        self.user_states[phone] = 'waiting_schedule_preference'
    
    def handle_address_coverage(self, phone, message_text):
        """Processa consulta de cobertura"""
        self.z_api.send_text_message(phone, f"Verificando cobertura para: {message_text}\n\n✅ Temos cobertura na sua região! Nossos planos disponíveis:\n\n📶 100MB - R$ 79,90\n📶 200MB - R$ 99,90\n📶 500MB - R$ 149,90\n\nDeseja contratar algum plano?")
        self.user_states[phone] = 'start'  # Reset
    
    def handle_address_contract(self, phone, message_text):
        """Processa contratação de internet"""
        self.z_api.send_text_message(phone, f"Endereço registrado: {message_text}\n\n✅ Temos cobertura! Nossos planos:\n\n📶 100MB - R$ 79,90\n📶 200MB - R$ 99,90\n📶 500MB - R$ 149,90\n\nNossa equipe comercial entrará em contato em até 2 horas para finalizar sua contratação!")
        self.user_states[phone] = 'start'  # Reset
    
    def handle_cpf_cancel(self, phone, message_text):
        """Processa CPF/CNPJ para cancelamento"""
        cpf_cnpj = re.sub(r'[^0-9]', '', message_text)
        
        if len(cpf_cnpj) == 11 or len(cpf_cnpj) == 14:
            self.z_api.send_text_message(phone, f"Documento {cpf_cnpj} localizado! Sua solicitação foi encaminhada para o setor responsável. Nossa equipe entrará em contato em até 24 horas.")
            self.user_states[phone] = 'start'  # Reset
        else:
            self.z_api.send_text_message(phone, "CPF ou CNPJ inválido. Por favor, digite novamente apenas os números.")

