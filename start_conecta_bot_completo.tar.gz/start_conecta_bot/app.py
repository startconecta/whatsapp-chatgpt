from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from z_api_client import ZAPIClient
from bot_logic import BotLogic

app = Flask(__name__)
CORS(app)

# Configurações do Z-API (devem ser definidas como variáveis de ambiente)
INSTANCE_ID = os.getenv('ZAPI_INSTANCE_ID', 'your_instance_id')
TOKEN = os.getenv('ZAPI_TOKEN', 'your_token')

# Inicializa o cliente Z-API e a lógica do bot
z_api = ZAPIClient(INSTANCE_ID, TOKEN)
bot = BotLogic(z_api)

@app.route('/', methods=['GET'])
def health_check():
    return jsonify({'status': 'Bot START Conecta está funcionando!', 'version': '1.0'}), 200

@app.route('/webhook', methods=['POST'])
def webhook():
    try:
        data = request.get_json()
        print('Webhook recebido:', data)
        
        # Verifica se é uma mensagem recebida
        if data and 'phone' in data and 'message' in data:
            phone = data['phone']
            message_text = data['message'].get('text', '').strip()
            
            # Ignora mensagens vazias
            if message_text:
                # Processa a mensagem usando a lógica do bot
                bot.process_message(phone, message_text)
        
        return jsonify({'status': 'success'}), 200
    
    except Exception as e:
        print(f"Erro no webhook: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/test', methods=['POST'])
def test_bot():
    """Endpoint para testar o bot localmente"""
    try:
        data = request.get_json()
        phone = data.get('phone', '5511999999999')
        message = data.get('message', '')
        
        bot.process_message(phone, message)
        
        return jsonify({'status': 'test_success', 'phone': phone, 'message': message}), 200
    
    except Exception as e:
        return jsonify({'status': 'test_error', 'message': str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)


